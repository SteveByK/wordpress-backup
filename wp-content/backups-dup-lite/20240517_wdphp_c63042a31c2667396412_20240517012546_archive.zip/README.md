# wordpress-php
 wordpress-php debug 
